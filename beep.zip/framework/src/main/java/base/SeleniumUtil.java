/**
 *
 * @author Tumelo
 */
package base;


public class SeleniumUtil {

    public static final String BASE_URL_STRING = "https://qa-styles.ppsisecure.co.za/";
 
    
   
}
