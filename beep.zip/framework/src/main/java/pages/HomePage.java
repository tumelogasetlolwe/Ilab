

/**
 *
 * @author Tumelo
 */

package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import base.Driver;
import base.SeleniumUtil;
import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertEquals;

public class HomePage {
    

   
    public static void LoadiLabWebsite() {
        Driver.getWebInstance().manage().window().maximize();
        Driver.getInstance().get(SeleniumUtil.BASE_URL_STRING);

        
    }

    private static WebElement ClickCareers() {
        return Driver.getInstance().wait(5, ExpectedConditions.
                presenceOfElementLocated(By.xpath("//*[@id=\"menu-item-1373\"]/a")));
    }

    private static WebElement ClickSouthAfrica() {
        return Driver.getInstance().wait(5, ExpectedConditions.
                presenceOfElementLocated(By.xpath("/html/body/section/div[2]/div/div/div/div[3]/div[2]/div/div/div[3]/div[2]/div/div/div[3]/a")));
    }

    private static WebElement ClickFirstPost() {
        return Driver.getInstance().wait(5, ExpectedConditions.
                presenceOfElementLocated(By.xpath("/html/body/section/div[2]/div/div/div/div[3]/div[2]/div/div/div/div/div/div[1]/div[1]/div[2]/div[1]/a")));
    }

    public static WebElement ClickApplyOnline() {
        return Driver.getInstance().wait(5, ExpectedConditions.
                presenceOfElementLocated(By.xpath("//*[@id=\"wpjb-scroll\"]/div[1]/a")));
    }

    public static void EnterYourName(String username) {
        
        Driver.getInstance().wait(5, ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"applicant_name\"]"))).sendKeys(username);
    }

    public static void EnterYourEmail(String usermail) {
      
        Driver.getInstance().wait(5, ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"email\"]"))).sendKeys(usermail);
    }

    public static void EnterYourPhoneNo(String numbers) {
        Driver.getInstance().wait(5, ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"phone\"]"))).sendKeys(numbers);

    }

    public static WebElement ClickSend() {
        return Driver.getInstance().wait(5, ExpectedConditions.
                presenceOfElementLocated(By.xpath("//*[@id=\"wpjb_submit\"]")));
    }
     
    public static void VerifyText(){
    
    WebElement message = Driver.getInstance().wait(5, ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"wpjb-apply-form\"]/fieldset[1]/div[5]/div/ul/li")));
            String messageText = message.getText();
            assertEquals("You need to upload at least one file.", messageText);
    }
   
    public static void ClickOnIlabCareers() {
        ClickCareers().click();

    }

    public static void ClickOnSouthAfrica() {
        ClickSouthAfrica().click();
    }

    public static void ClickOnFirstPost() {
        ClickFirstPost().click();
    }

    public static void ClickOnApplyOnline() {
        ClickApplyOnline().click();
    }

    public static void ClickOnSend() {
        ClickSend().click();
    }
    
    

}
