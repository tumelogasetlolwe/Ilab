/**
 *
 * @author Tumelo
 */
package testing;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import base.Framework;
import static org.junit.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import pages.HomePage;
//import zar.hsh.mcc.framework.base.Driver;


public class Careers_Test {

    @Before
    public void setUp() {
        Framework.resetDriver();
        Framework.generateRandomNumber(0);
    }

//execute test
    @Test
    public void execute() {
        try {
            HomePage.LoadiLabWebsite();
            HomePage.ClickOnIlabCareers();
            HomePage.ClickOnSouthAfrica();
            HomePage.ClickOnFirstPost();
            HomePage.ClickOnApplyOnline();
            HomePage.EnterYourName("Tumelo");
            HomePage.EnterYourEmail("automationAssessment@iLABQuality.com");
            HomePage.EnterYourPhoneNo("0731352635");
            HomePage.ClickOnSend();
            HomePage.VerifyText();
            
            
          

        } catch (Exception e) {
            System.out.println(e.getMessage());
            
        }
    }



    @After
    public void cleanUp() {
       
    }

  

}
